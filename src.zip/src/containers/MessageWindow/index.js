import MessageWindow from "./MessageWindow";

export default MessageWindow;
