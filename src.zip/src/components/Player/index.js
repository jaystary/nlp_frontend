import Player from "./Player";

export default Player;