import React, { Component } from "react";

class Header extends Component {
  render() {
    return null
  }
}

export default Header;