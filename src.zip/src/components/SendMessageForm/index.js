import SendMessageForm from "./SendMessageForm";

export default SendMessageForm;